//---------------------------------------------------------------------------

#ifndef Main_FormH
#define Main_FormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Chart.hpp>
#include <ExtCtrls.hpp>
#include <Series.hpp>
#include <TeEngine.hpp>
#include <TeeProcs.hpp>
#include <Dialogs.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
        TChart *Chart1;
        TLineSeries *Series1;
        TChart *Chart2;
        TComboBox *WaveletsCB;
        TButton *ShWvlBt;
        TCheckBox *AbsValCb;
        TButton *MkCWTBut;
        TButton *OpnBut;
        TLabel *Label1;
        TFastLineSeries *Series2;
        TOpenDialog *OpenDlg;
        TEdit *AstepE;
        TLabel *Label3;
        TEdit *AmaxE;
        TLabel *Label4;
        TEdit *AminE;
        TLabel *Label2;
        TTrackBar *PrecTB;
        TLabel *Label5;
        TLabel *PrecVal;
        void __fastcall OpnButClick(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall MkCWTButClick(TObject *Sender);
        void __fastcall AbsValCbClick(TObject *Sender);
        void __fastcall ShWvlBtClick(TObject *Sender);
        void __fastcall PrecTBChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
