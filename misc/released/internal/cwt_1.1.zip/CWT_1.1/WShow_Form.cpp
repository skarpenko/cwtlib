//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "WShow_Form.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TWShowForm *WShowForm;
//---------------------------------------------------------------------------
__fastcall TWShowForm::TWShowForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
