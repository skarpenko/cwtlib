//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <math.h>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include "cwtwlets.h"
#include "cwt.h"
#include "Main_Form.h"
#include "Wait_Form.h"
#include "WShow_Form.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

using namespace std;

typedef struct {
  TLogPalette lPal;
  TPaletteEntry dummy[256];
} LogPal;

LogPal Palette;
vector<double> SigData;
cwt_t wt = {0.0, 0.0, 0, 0, NULL };
Graphics::TBitmap *Bmp;
TPicture *Pic;
double Min, Max, fMin, fMax;

double fmin(cwt_t *wt)
{
    long i,j;
    double temp;

    temp = wt->cwt[0][0];
    for(i=0; i < wt->rows; i++)
       for(j=0; j < wt->cols; j++)
          if(wt->cwt[i][j] < temp)
            temp = wt->cwt[i][j];

    return temp;
}

double fmax(cwt_t *wt)
{
    long i,j;
    double temp;

    temp = wt->cwt[0][0];
    for(i=0; i < wt->rows; i++)
       for(j=0; j < wt->cols; j++)
          if(wt->cwt[i][j] > temp)
            temp = wt->cwt[i][j];

    return temp;
}

double ffmin(cwt_t *wt)
{
    long i,j;
    double temp;

    temp = fabs(wt->cwt[0][0]);
    for(i=0; i < wt->rows; i++)
       for(j=0; j < wt->cols; j++)
          if(fabs(wt->cwt[i][j]) < temp)
            temp = fabs(wt->cwt[i][j]);

    return temp;
}

double ffmax(cwt_t *wt)
{
    long i,j;
    double temp;

    temp = fabs(wt->cwt[0][0]);
    for(i=0; i < wt->rows; i++)
       for(j=0; j < wt->cols; j++)
          if(fabs(wt->cwt[i][j]) > temp)
            temp = fabs(wt->cwt[i][j]);

    return temp;
}

TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
        : TForm(Owner)
{
      Graphics::TBitmap *bmp;
      TPicture *pict;
      long i,j;
      Byte *ptr;

      Palette.lPal.palVersion = 0x300;
      Palette.lPal.palNumEntries = 256;

      for(i=0; i<256; i++)
      {
           Palette.lPal.palPalEntry[i].peRed=i;
           Palette.lPal.palPalEntry[i].peGreen=i;
           Palette.lPal.palPalEntry[i].peBlue=i;
           Palette.lPal.palPalEntry[i].peFlags=0;
      }
      Bmp = new Graphics::TBitmap();
      Pic = new TPicture();

      Bmp->Height = 512;
      Bmp->Width = 512;
      Bmp->PixelFormat = pf8bit;
      Bmp->Palette = CreatePalette(&Palette.lPal);
      Bmp->Dormant();

      Pic->Assign(Bmp);

     Chart1->BackImage = Pic;
     Chart1->BackImageMode = pbmStretch;
     Chart1->BackImageInside = true;

     WaveletsCB->Items->Add("������������ �����");
     WaveletsCB->Items->Add("�����");
     WaveletsCB->ItemIndex = 0;

     PrecVal->Caption = IntToStr(PrecTB->Position);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::OpnButClick(TObject *Sender)
{
        AnsiString mesg;
        AnsiString filename;
        unsigned delimoff;
        fstream fstrm;
        double temp;
        long i;

        OpenDlg->Filter = "������ ��������� ������� (*.txt)|*.txt";
        OpenDlg->FileName = "";

        if(OpenDlg->Execute()){
            filename = OpenDlg->FileName;
            if(!filename.data()) return;

            fstrm.open((char *)filename.c_str(), ios::in);
            if(!fstrm) {
                    mesg="������ ��� �������� �����: ";
                    delimoff = filename.LastDelimiter("\\");
                    mesg+=filename.SubString(delimoff+1, INT_MAX);
                    MessageBox(NULL, mesg.c_str(), "������", 0);
                    return;
            }
            SigData.clear();
            do {
                    fstrm >> temp;
                    SigData.push_back(temp);
            } while(fstrm);
            fstrm.close();

            SigData.erase(&SigData[SigData.size()-1]);

            Bmp->Height = 0;
            Bmp->Width = 0;
            Bmp->Height = 512;
            Bmp->Width = 512;

            Pic->Assign(Bmp);
            Chart1->BackImage = Pic;

            if(wt.cwt != NULL)
                free_cwt(&wt);
            Series1->Clear();
            Series2->Clear();
            for(i=0; i<SigData.size(); i++)
                Series2->AddXY(i, SigData[i], "", clTeeColor);
        } else return;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormClose(TObject *Sender, TCloseAction &Action)
{
        delete Bmp; delete Pic;
        if(wt.cwt!=NULL)
           free_cwt(&wt);
        SigData.clear();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::MkCWTButClick(TObject *Sender)
{
        double amin, astep, amax;
        double C;
        long i,j,k;
        Byte *ptr;
        wavelet_t *psi;
        unsigned prec;

        if(SigData.empty()) {
                MessageBox(NULL, "��������� ������", "���������", 0);
                return;
        }

        amin = StrToFloat(AminE->Text);
        astep = StrToFloat(AstepE->Text);
        amax = StrToFloat(AmaxE->Text);
        prec = PrecTB->Position;

        if(WaveletsCB->ItemIndex == 0)
           psi = &MEXHAT;
        else
           psi = &MORLETreal;

        WaitForm->Show();
        WaitForm->Update();
        if(cwt(&SigData[0], SigData.size(), amin, astep, amax,
             1.0, prec, psi, &wt)) {
             WaitForm->Hide();
             MessageBox(NULL, "������ ��������������", "������", 0);
             return;
        }

        Min = fmin(&wt);
        Max = fmax(&wt);
        fMin = ffmin(&wt);
        fMax = ffmax(&wt);
        WaitForm->Hide();

        Bmp->Width = wt.cols;
        Bmp->Height = wt.rows;

        for(i=0; i < wt.rows; i++) {
          ptr = (byte *)Bmp->ScanLine[i];
          for(j=0; j < wt.cols; j++) {
              C = wt.cwt[wt.rows-1-i][j];
              if(AbsValCb->Checked) {
                 k = 512 * (fabs(C) - fMin)/(fMax-fMin);
                 if(k>255) ptr[j] = 255; else
                 ptr[j] = (byte)k;
              }
              else {
                 k= 256 * (C - Min)/(Max-Min);
                 if(k>255) ptr[j] = 255; else
                 ptr[j] = (byte)k;
              }
          }
        }

        Pic->Assign(Bmp);
        Chart1->BackImage = Pic;
        Series1->Clear();
        Series1->AddXY(0, wt.amin, "", clTeeColor);
        Series1->AddXY(wt.cols-1, wt.amin, "", clTeeColor);
        Series1->AddXY(wt.cols-1, wt.amax, "", clTeeColor);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::AbsValCbClick(TObject *Sender)
{
        byte *ptr;
        long i,j,k;
        double C;

        if(wt.cwt == NULL) return;

        for(i=0; i < wt.rows; i++) {
          ptr = (byte *)Bmp->ScanLine[i];
          for(j=0; j < wt.cols; j++) {
              C = wt.cwt[wt.rows-1-i][j];
              if(AbsValCb->Checked) {
                 k = 512 * (fabs(C) - fMin)/(fMax-fMin);
                 if(k>255) ptr[j] = 255; else
                 ptr[j] = (byte)k;
              }
              else {
                 k= 256 * (C - Min)/(Max-Min);
                 if(k>255) ptr[j] = 255; else
                 ptr[j] = (byte)k;
              }
          }
        }

        Pic->Assign(Bmp);
        Chart1->BackImage = Pic;
        Series1->Clear();
        Series1->AddXY(0, wt.amin, "", clTeeColor);
        Series1->AddXY(wt.cols-1, wt.amin, "", clTeeColor);
        Series1->AddXY(wt.cols-1, wt.amax, "", clTeeColor);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ShWvlBtClick(TObject *Sender)
{
        double i;

        if(WaveletsCB->ItemIndex == 0) {
            WShowForm->Chart1->Title->Text->Clear();
            WShowForm->Chart1->Title->Text->Add("������� ������������ �����");
            WShowForm->Series1->Clear();
            WShowForm->Series2->Clear();
            for(i=-5.0; i<=5.0; i+=0.01)
               WShowForm->Series1->AddXY(i, MEXHAT(i, 1.0, 0.0), "", clTeeColor);
        }
        else
        {
            WShowForm->Chart1->Title->Text->Clear();
            WShowForm->Chart1->Title->Text->Add("������� �����");
            WShowForm->Series1->Clear();
            WShowForm->Series2->Clear();
            for(i=-5.0; i<=5.0; i+=0.01) {
               WShowForm->Series1->AddXY(i, MORLETreal(i, 1.0, 0.0), "", clTeeColor);
               WShowForm->Series2->AddXY(i, MORLETimag(i, 1.0, 0.0), "", clTeeColor);
            }
        }

        WShowForm->Show();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PrecTBChange(TObject *Sender)
{
     PrecVal->Caption = IntToStr(PrecTB->Position);
}
//---------------------------------------------------------------------------

