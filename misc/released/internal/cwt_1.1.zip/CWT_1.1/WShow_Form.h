//---------------------------------------------------------------------------

#ifndef WShow_FormH
#define WShow_FormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Chart.hpp>
#include <ExtCtrls.hpp>
#include <Series.hpp>
#include <TeEngine.hpp>
#include <TeeProcs.hpp>
//---------------------------------------------------------------------------
class TWShowForm : public TForm
{
__published:	// IDE-managed Components
        TChart *Chart1;
        TLineSeries *Series1;
        TLineSeries *Series2;
private:	// User declarations
public:		// User declarations
        __fastcall TWShowForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TWShowForm *WShowForm;
//---------------------------------------------------------------------------
#endif
