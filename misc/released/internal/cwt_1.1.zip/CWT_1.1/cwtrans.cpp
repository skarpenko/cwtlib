//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("cwtrans.res");
USEFORM("Main_Form.cpp", MainForm);
USEFORM("Wait_Form.cpp", WaitForm);
USEFORM("WShow_Form.cpp", WShowForm);
USEUNIT("cwtlib\cwt.c");
USEUNIT("cwtlib\cwtwlets.c");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TMainForm), &MainForm);
                 Application->CreateForm(__classid(TWaitForm), &WaitForm);
                 Application->CreateForm(__classid(TWShowForm), &WShowForm);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
